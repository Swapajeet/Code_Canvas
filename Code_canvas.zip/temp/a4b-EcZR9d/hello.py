
print("Hello, World!")